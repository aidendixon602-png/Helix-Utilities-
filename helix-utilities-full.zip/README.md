# Helix Utilities — all-in-one Discord bot + dashboard

```
helix/
├── bot/         discord.js v14 bot, stats API, Docker setup
└── dashboard/   Next.js dashboard (Discord login, per-server settings, live stats) → Vercel
```

Both parts share one MongoDB database. The dashboard edits settings directly in MongoDB and pings the bot (through a Cloudflare Tunnel) so changes apply instantly.

---

## Features

**🛡️ Security** — `/antinuke` (ban/kick/channel/role/webhook/emoji flood limits, bot-add block, prune block, dangerous role & permission grants reverted, vanity URL protection, auto-revert of created channels/roles/webhooks), `/automod` (spam, caps, links + allowlist, invites, mass mentions, emoji spam, blocked words, ignored channels/roles), `/whitelist`, `/unwhitelist`, `/lockdown start|end` (remembers and restores every channel's previous permissions).

**⚙️ Management** — `/ban /unban /softban /kick /mute /unmute /warn /purge /lock /unlock /slowmode /jail /nick /role`, full logging (`/logs setup` creates every channel), `/reactionrole`, `/vanityrole`, `/invites` tracker (regular/left/fake/bonus), `/ticket` (panel, claim, close, transcripts), `/giveaway` (button entry, required role, reroll), `/verification` (button + captcha), `/jtc` + `/voice` join-to-create channels, `/welcome`.

**🎉 Engagement** — `/rank`, `/leaderboard`, `/levels` (role rewards, multiplier, no-XP channels), `/birthday`, `/afk`, `/autorole`, `/autoresponder`, `/sticky`, `/counting`, `/booster` (thank-you message + custom booster roles), economy (`/balance /daily /give /blackjack /slots`) and **16 mini-games** under `/game`: chess, battleship, tictactoe, connect4, wordle, 2048, minesweeper, snake, memory, rps, hangman, trivia, guess, fasttype, coinflip, dice.

**🌐 Dashboard** — Discord OAuth2 login, server picker, settings for every module (antinuke is server-owner-only), live stats with charts, branding via env vars, deploys to Vercel.

52 slash commands total (Discord allows 100).

---

## 1. Discord application

1. Create an app at <https://discord.com/developers/applications>.
2. **Bot** tab → Reset Token (this is `DISCORD_TOKEN`). Turn on all three **Privileged Gateway Intents**: Presence, Server Members, Message Content.
3. **OAuth2** tab → copy Client ID and Client Secret. Add redirect: `https://YOUR-DASHBOARD.vercel.app/api/auth/callback`.
4. Invite the bot with `https://discord.com/oauth2/authorize?client_id=CLIENT_ID&permissions=8&scope=bot%20applications.commands`.
5. In each server, drag the bot's role **to the top** — antinuke can only stop people below it.

## 2. MongoDB

Create a free cluster on MongoDB Atlas, add a database user, allow network access (`0.0.0.0/0` is simplest for Vercel), and copy the connection string into `MONGODB_URI` for both the bot and the dashboard.

## 3. Run the bot

```bash
cd bot
cp .env.example .env        # fill it in
npm install
npm run check               # offline sanity check of every command & module
npm run deploy              # register slash commands (set DEV_GUILD_ID for instant testing)
```

**Option A — Docker:**

```bash
docker compose up -d                       # bot
docker compose --profile tunnel up -d      # …plus the Cloudflare Tunnel (step 4)
```

**Option B — manual:** `npm start` in `bot/` (Node 18.17+). Use a process manager like `pm2` to keep it running.

## 4. Permanent HTTPS URL with Cloudflare Tunnel

The dashboard reads live stats from the bot's API (port `3001`). A **named** tunnel gives it a URL that never changes.

1. Add a domain to Cloudflare (free plan is fine).
2. Cloudflare dashboard → **Zero Trust → Networks → Tunnels → Create tunnel** (cloudflared). Name it `helix`.
3. Copy the tunnel token into `CLOUDFLARE_TUNNEL_TOKEN` in `bot/.env`.
4. Add a **Public hostname**: `api.yourdomain.com` → service `http://bot:3001` (Docker) or `http://localhost:3001` (manual).
5. Start it: `docker compose --profile tunnel up -d` — or without Docker: `cloudflared tunnel run --token <TOKEN>`.

Check: `https://api.yourdomain.com/health` → `{"ok":true,...}`. Put that URL in the dashboard's `BOT_API_URL`.

## 5. Deploy the dashboard to Vercel

1. Push this repo to GitHub.
2. Vercel → **Add New Project** → import the repo → set **Root Directory** to `dashboard`.
3. Add every variable from `dashboard/.env.example` (`PUBLIC_URL` = your Vercel URL, `BOT_API_KEY` = the bot's `API_KEY`, `SESSION_SECRET` = any long random string).
4. Deploy. Make sure the OAuth2 redirect in step 1 matches `PUBLIC_URL/api/auth/callback`.
5. Set `DASHBOARD_URL` in the bot's `.env` so `/dashboard` and `/help` link to it.

Local dev: `cd dashboard && cp .env.example .env.local && npm install && npm run dev` (use `PUBLIC_URL=http://localhost:3000` and add that redirect in Discord too).

### Branding
Change `NEXT_PUBLIC_BRAND_NAME`, `_TAGLINE`, `_COLOR`, `_LOGO`, `_SUPPORT_URL` and redeploy. On the bot side, `BOT_NAME` and `EMBED_COLOR` control embeds.

---

## Adding settings later
Settings live in `bot/src/models/Guild.js`. The dashboard has a copy at `dashboard/lib/models/Guild.cjs` — keep them in sync. To make a new setting editable from the dashboard, add its path to `dashboard/lib/settingsSpec.js` (anything not listed there is ignored for safety) and a field in `SettingsForm.js`.

## Security notes
- Antinuke and the whitelist can only be changed by the **server owner** (in Discord and on the dashboard).
- The dashboard's login cookie is encrypted (it contains the Discord access token) and every save is re-checked against the user's Manage Server permission.
- The stats API requires `x-api-key`; only `/health` and `/public` (server/user counts) are open.
